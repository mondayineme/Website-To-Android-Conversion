package com.example.inemesmartnews;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {
    private ProgressDialog progressDialog;
    private WebView MyWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MyWebView = findViewById(R.id.webview);
        WebSettings webSettings = MyWebView.getSettings();

        progressDialog =new ProgressDialog(this);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        webSettings.setJavaScriptEnabled(true);
        MyWebView.loadUrl("http://inemesmart.com.ng/");
        //Code for opening the app
        MyWebView.setWebViewClient(new WebViewClient());
    }

    //Code for back button

    @Override
    public void onBackPressed() {
        if (MyWebView.canGoBack()){
            MyWebView.goBack();
        }else{
            super.onBackPressed();
        }

    }
}